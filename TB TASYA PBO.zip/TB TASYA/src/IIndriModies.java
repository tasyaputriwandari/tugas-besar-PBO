import java.util.Scanner;

// Interface standar sistem (Poin b) [cite: 41]
public interface IIndriModies {
    void kelolaPelanggan(Scanner sc);
    void inputPesanan(Scanner sc);
    void lihatJadwal();
    void logSesi();
}